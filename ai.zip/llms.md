# smart.who.int.ig-empty#0.1.0: HIV Ethiopia Empty IG

## Pages

* [Home](index.md)
* [User Scenarios](scenarios.md)
* [Data Dictionary](dictionary.md)
* [Non-functional Requirements](non-functional-requirements.md)
* [Business Processes](business-processes.md)
* [Indicators and Measures](indicators-measures.md)
* [Downloads](downloads.md)
* [Data Models and Exchange](data-models-and-exchange.md)
* [Trust Domains](trust_domain.md)
* [Codings](codings.md)
* [Business Requirements](business-requirements.md)
* [Indices](indices.md)
* [System Actors](system-actors.md)
* [Testing](testing.md)
* [Generic Personas](personas.md)
* [Reference Implementations](reference-implementations.md)
* [Dependencies](dependencies.md)
* [Artifact Index](artifacts.md)
* [Sequence Diagrams](sequence-diagrams.md)
* [Functional Requirements](functional-requirements.md)
* [Adapting Guidelines for Country use](adapting.md)
* [Test Data](test-data.md)
* [DAK API Documentation Hub](dak-api.md)
* [Decision-support logic](decision-logic.md)
* [License](license.md)
* [Transactions](transactions.md)
* [Deployment](deployment.md)
* [Changes](changes.md)
* [Mappings](maps.md)
* [References](references.md)
* [Security and Privacy Considerations](security-privacy.md)
* [Indicator and Performance Metrics](indicators.md)
* [Concepts](concepts.md)

## Resources

### ImplementationGuides

* [HIV Ethiopia Empty IG](index.md)
